package com.trainee.controller;

public class TraineeController {

}
