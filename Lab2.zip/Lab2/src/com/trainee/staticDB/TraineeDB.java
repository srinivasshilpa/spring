package com.trainee.staticDB;

import java.util.HashMap;

import com.trainee.bean.TraineeBean;

public class TraineeDB {
static HashMap<Integer, TraineeBean> productIdMap = getProductIdMap();
	
	static {
		if(productIdMap == null){
			productIdMap = new HashMap<Integer, Product>();
			
			Product a = new Product(1,"Ipad",50000);
			Product b = new Product(2,"Phone",12000);
			Product c = new Product(3,"Iphone",80000);
			Product d = new Product(4,"DVD",40000);
			Product e = new Product(5,"TV",60000);
			
			productIdMap.put(1, a);
			productIdMap.put(2, b);
			productIdMap.put(3, c);
			productIdMap.put(4, d);
			productIdMap.put(5, e);
		}
	}
	
	public static HashMap<Integer, Product> getProductIdMap(){
		return productIdMap;
		
	}
}
