package com.ems.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_tbl")
public class EmployeeBean {

	@Id
	@GeneratedValue
	@Column(name="empId")
	private int employeeId;
	@Column(name="empName",length=15)
	private String employeeName;
	@Column(name="empSalary")
	private double employeeSalary;
	
	
	public EmployeeBean() {
		super();
	}
	
	
	public EmployeeBean(int employeeId, String employeeName,
			double employeeSalary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	
	
	
	
	public String getEmployeeName() {
		return employeeName;
	}
	
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
	
	
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
	
	
}
