package com.ems.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;

@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao {
   
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id=0;
		try {
			entityManager.persist(bean);
			entityManager.flush();
			id=bean.getEmployeeId();
		} catch (Exception e) {
			throw new EmployeeException("Unable to persist in dao layer "+e.getMessage());
		}
		return id;
	}

	@Override
	public List<EmployeeBean> viewAllEmployees() throws EmployeeException {
		List<EmployeeBean> list = null;
		try {
			TypedQuery<EmployeeBean> query = entityManager.createQuery("from EmployeeBean" ,EmployeeBean.class);
			list = query.getResultList();
		} catch (Exception e) {
			
			throw new EmployeeException("Unable to fetch record"+e.getMessage());
		}
		
		
		return list;
	}

	@Override
	public boolean deleteEmployee(int id) throws EmployeeException {
		    EmployeeBean bean;
		    try {
				bean = entityManager.find(EmployeeBean.class, id);

				entityManager.remove(bean);
			} catch (Exception e) {
				throw new EmployeeException("Unable to delete record"+e.getMessage());
			}
			return true;
	}

	@Override
	public boolean updateEmployee(EmployeeBean bean) throws EmployeeException {
		
		try {
			EmployeeBean emp = entityManager.find(EmployeeBean.class, bean.getEmployeeId());
			emp.setEmployeeName(bean.getEmployeeName());
			emp.setEmployeeSalary(bean.getEmployeeSalary());
		entityManager.merge(emp);
		} catch (Exception e) {
			throw new EmployeeException("Unable to update record"+e.getMessage());
		}
		return true;
	}

}
