package com.test.bean;

import javax.validation.constraints.Size;

public class EmployeeBean {
	
    private int employeeID;
    
    @Size(min=2,max=5,message="Name should contain min 2 and max 5 characters")
    private String employeeName;
	
    public int getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public EmployeeBean() {
		super();
	}
	public EmployeeBean(int employeeID, String employeeName) {
		super();
		this.employeeID = employeeID;
		this.employeeName = employeeName;
	}
    
    
}
