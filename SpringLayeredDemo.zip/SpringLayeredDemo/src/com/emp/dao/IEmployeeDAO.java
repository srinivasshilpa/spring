package com.emp.dao;

import com.emp.bean.Employee;

public interface IEmployeeDAO {
      public void addEmployee(Employee emp);
      
}
