package com.emp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emp.bean.Employee;
import com.emp.dao.IEmployeeDAO;

@Service
public class EmployeeServiceImpl implements IEmployeeService {
	
	@Autowired
	IEmployeeDAO employeeDao; 
	
	
	public IEmployeeDAO getEmployeeDao() {
		return employeeDao;
	}
	public void setEmployeeDao(IEmployeeDAO employeeDao) {
		this.employeeDao = employeeDao;
	}
/*	public EmployeeServiceImpl(IEmployeeDAO employeeDao) {
		super();
		this.employeeDao = employeeDao;
	}
	public EmployeeServiceImpl() {
		super();
	}*/
	
	@Override
	public void addEmployee(Employee emp) {
		
      employeeDao.addEmployee(emp);
	}

}
