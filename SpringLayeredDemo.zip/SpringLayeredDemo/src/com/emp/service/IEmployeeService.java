package com.emp.service;

import com.emp.bean.Employee;

public interface IEmployeeService {
    public void addEmployee(Employee emp);
    
    
}
